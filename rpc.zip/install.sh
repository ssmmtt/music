rm -rf /etc/rpc
mkdir -p /etc/rpc
rm -rf /usr/local/rpc
\cp -r ./rpc /usr/local
mkdir -p /usr/local/rpc/logs
rm -f /usr/bin/rpc /usr/lib/systemd/system/rpc*
ln -s /usr/local/rpc/rpc.ini /etc/rpc/rpc.ini
ln -s /usr/local/rpc/rpc /usr/bin/rpc
\cp /usr/local/rpc/systemd/rpc* /usr/lib/systemd/system/
